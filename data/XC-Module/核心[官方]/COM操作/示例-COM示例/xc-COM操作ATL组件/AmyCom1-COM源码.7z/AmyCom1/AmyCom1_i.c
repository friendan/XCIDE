

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 8.01.0622 */
/* at Tue Jan 19 11:14:07 2038
 */
/* Compiler settings for AmyCom1.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.01.0622 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */



#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        EXTERN_C __declspec(selectany) const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif // !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IATLSimpleObject,0x503d4a0c,0x7860,0x48ad,0x8c,0x0d,0x12,0xd4,0x70,0xe1,0x45,0x67);


MIDL_DEFINE_GUID(IID, IID_IATLSimpleObject2,0x8918881a,0x0d1e,0x4618,0xb7,0x7a,0x19,0xb3,0xdc,0x85,0xba,0xd4);


MIDL_DEFINE_GUID(IID, LIBID_AmyCom1Lib,0x4190a30c,0x7b05,0x4ef6,0xa6,0xe2,0x89,0x8d,0x35,0xfb,0xe6,0x73);


MIDL_DEFINE_GUID(CLSID, CLSID_ATLSimpleObject,0x94728d27,0x5703,0x4500,0xb0,0x0f,0xd7,0x34,0xb6,0x6d,0x5c,0x0d);


MIDL_DEFINE_GUID(CLSID, CLSID_ATLSimpleObject2,0xff2ed29d,0x080c,0x48a6,0xab,0xc2,0xa8,0xe4,0x91,0x5d,0x99,0x2b);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



