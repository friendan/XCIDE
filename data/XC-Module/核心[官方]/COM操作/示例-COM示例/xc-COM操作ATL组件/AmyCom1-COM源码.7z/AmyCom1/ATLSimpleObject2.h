﻿// ATLSimpleObject2.h: CATLSimpleObject2 的声明

#pragma once
#include "resource.h"       // 主符号



#include "AmyCom1_i.h"



#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Windows CE 平台(如不提供完全 DCOM 支持的 Windows Mobile 平台)上无法正确支持单线程 COM 对象。定义 _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA 可强制 ATL 支持创建单线程 COM 对象实现并允许使用其单线程 COM 对象实现。rgs 文件中的线程模型已被设置为“Free”，原因是该模型是非 DCOM Windows CE 平台支持的唯一线程模型。"
#endif

using namespace ATL;


// CATLSimpleObject2

class ATL_NO_VTABLE CATLSimpleObject2 :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CATLSimpleObject2, &CLSID_ATLSimpleObject2>,
	public IDispatchImpl<IATLSimpleObject2, &IID_IATLSimpleObject2, &LIBID_AmyCom1Lib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CATLSimpleObject2()
	{
	}

DECLARE_REGISTRY_RESOURCEID(107)

BEGIN_COM_MAP(CATLSimpleObject2)
	COM_INTERFACE_ENTRY(IATLSimpleObject2)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:

	STDMETHOD(Add)(LONG a, LONG b, LONG* ret);
	STDMETHOD(Add2)(LONG a, LONG* ret1, LONG* ret2);
	STDMETHOD(GetText)(LONG  a, BSTR* ret, BSTR* ret2);
	STDMETHOD(get_Name)(BSTR* pVal);
	STDMETHOD(put_Name)(BSTR newVal);
    STDMETHOD(Method)();
};

OBJECT_ENTRY_AUTO(__uuidof(ATLSimpleObject2), CATLSimpleObject2)
