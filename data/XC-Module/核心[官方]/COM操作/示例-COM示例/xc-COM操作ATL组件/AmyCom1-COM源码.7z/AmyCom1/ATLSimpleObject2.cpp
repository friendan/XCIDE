﻿// ATLSimpleObject2.cpp: CATLSimpleObject2 的实现

#include "pch.h"
#include "ATLSimpleObject2.h"


// CATLSimpleObject2
STDMETHODIMP CATLSimpleObject2::Add(LONG a, LONG b, LONG* ret)
{
	wchar_t buf[MAX_PATH] = { 0 };
	swprintf_s(buf, L"Add(%d, %d)", a, b);
	::MessageBox(NULL, buf, L"DEBUG", 0);

	*ret = a + b;
    return S_OK;
}

STDMETHODIMP CATLSimpleObject2::Add2(LONG a, LONG* ret1, LONG* ret2)
{
	wchar_t buf[MAX_PATH] = { 0 };
	swprintf_s(buf, L"Add2(%d, %d)", a, *ret1);
	::MessageBox(NULL, buf, L"DEBUG", 0);

	*ret1 = a;
	*ret2 = a;
	return S_OK;
}

STDMETHODIMP CATLSimpleObject2::GetText(LONG  a, BSTR* ret, BSTR* ret2)
{
	wchar_t buf[MAX_PATH] = { 0 };
	swprintf_s(buf, L"GetText(%d, \"%s\")", a, (const wchar_t*)(*ret));
	::MessageBox(NULL, buf, L"DEBUG", 0);

	SysReleaseString(*ret);
	*ret = ::SysAllocString(L"abc");

	*ret2 = ::SysAllocString(L"返回的字符串");
	return S_OK;
}

STDMETHODIMP CATLSimpleObject2::get_Name(BSTR* pVal)
{
	wchar_t buf[MAX_PATH] = { 0 };
	swprintf_s(buf, L"get_Name(无参数)");
	::MessageBox(NULL, buf, L"DEBUG", 0);

	*pVal = ::SysAllocString(L"返回的name");
	return S_OK;
}

STDMETHODIMP CATLSimpleObject2::put_Name(BSTR newVal)
{
	wchar_t buf[MAX_PATH] = { 0 };
	swprintf_s(buf, L"put_Name(\"%s\")", (const wchar_t*)(newVal));
	::MessageBox(NULL, buf, L"DEBUG", 0);

	return S_OK;
}

STDMETHODIMP CATLSimpleObject2::Method()
{
	::MessageBox(NULL, L"Method(无参数)", L"DEBUG", 0);
	return S_OK;
}
