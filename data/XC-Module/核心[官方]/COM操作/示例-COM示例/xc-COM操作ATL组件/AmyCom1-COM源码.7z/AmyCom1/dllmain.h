﻿// dllmain.h: 模块类的声明。

class CAmyCom1Module : public ATL::CAtlDllModuleT< CAmyCom1Module >
{
public :
	DECLARE_LIBID(LIBID_AmyCom1Lib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_AMYCOM1, "{4190a30c-7b05-4ef6-a6e2-898d35fbe673}")
};

extern class CAmyCom1Module _AtlModule;
