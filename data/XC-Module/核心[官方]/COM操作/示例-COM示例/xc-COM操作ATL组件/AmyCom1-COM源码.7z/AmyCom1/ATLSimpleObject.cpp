﻿// ATLSimpleObject.cpp: CATLSimpleObject 的实现

#include "pch.h"
#include "ATLSimpleObject.h"


// CATLSimpleObject



STDMETHODIMP CATLSimpleObject::Add(LONG a, LONG b, LONG*  ret)
{
	// TODO: 在此处添加实现代码
	*ret = a + b;

	return S_OK;
}
